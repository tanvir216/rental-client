import { redirect } from "next/navigation";
export default function Page() {
  redirect("/dashboard/customer/rentals");
}
